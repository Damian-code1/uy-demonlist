-- =============================================
-- UY Demonlist — Schema v2
-- Ejecutar: mysql -u root -p uy_demonlist < schema.sql
-- =============================================

SET FOREIGN_KEY_CHECKS = 0;

-- Users (Discord login)
CREATE TABLE IF NOT EXISTS users (
  id                   INT AUTO_INCREMENT PRIMARY KEY,
  discord_id           VARCHAR(255) UNIQUE NOT NULL,
  discord_username     VARCHAR(255) NOT NULL,
  discord_display_name VARCHAR(255),
  discord_avatar       VARCHAR(255),
  discord_email        VARCHAR(255),
  role                 ENUM('owner','admin','list_mod','usuario') DEFAULT 'usuario',
  created_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at           TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_discord_id (discord_id),
  INDEX idx_role (role)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Levels
CREATE TABLE IF NOT EXISTS levels (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  name        VARCHAR(255) NOT NULL,
  position    INT NOT NULL,
  placement   INT COMMENT 'AREDL position',
  youtube_url TEXT,
  two_player  BOOLEAN DEFAULT FALSE,
  legacy      BOOLEAN DEFAULT FALSE,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_position (position)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Victors (completions)
CREATE TABLE IF NOT EXISTS victors (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  level_id        INT NOT NULL,
  player_name     VARCHAR(255) NOT NULL,
  video_url       TEXT,
  completion_date DATE,
  verified        BOOLEAN DEFAULT FALSE,
  created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (level_id) REFERENCES levels(id) ON DELETE CASCADE,
  INDEX idx_level_id (level_id),
  INDEX idx_player_name (player_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Players (aggregated stats, updated via triggers/admin)
CREATE TABLE IF NOT EXISTS players (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(255) UNIQUE NOT NULL,
  points        INT DEFAULT 0,
  completions   INT DEFAULT 0,
  hardest_level VARCHAR(255),
  created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_points (points),
  INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Submissions
CREATE TABLE IF NOT EXISTS submissions (
  id           INT AUTO_INCREMENT PRIMARY KEY,
  username     VARCHAR(255) NOT NULL,
  level_name   VARCHAR(255) NOT NULL,
  youtube_url  TEXT NOT NULL,
  raw_url      TEXT,
  percentage   INT DEFAULT 100,
  is_100       BOOLEAN DEFAULT TRUE,
  notes        TEXT,
  status       ENUM('pending','approved','rejected') DEFAULT 'pending',
  submitted_by INT,
  created_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at   TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (submitted_by) REFERENCES users(id) ON DELETE SET NULL,
  INDEX idx_status (status),
  INDEX idx_username (username)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Audit log
CREATE TABLE IF NOT EXISTS audit_log (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT NOT NULL,
  action      VARCHAR(255) NOT NULL,
  entity_type VARCHAR(50),
  entity_id   INT,
  old_values  JSON,
  new_values  JSON,
  created_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  INDEX idx_action (action),
  INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

SET FOREIGN_KEY_CHECKS = 1;

-- ─── Default owner (ACTUALIZAR con tu Discord ID) ───
-- Descomentar y reemplazar YOUR_DISCORD_ID con tu ID real de Discord
-- INSERT INTO users (discord_id, discord_username, discord_display_name, role)
-- VALUES ('YOUR_DISCORD_ID', 'tuusuario', 'Tu Nombre', 'owner')
-- ON DUPLICATE KEY UPDATE role = 'owner';
