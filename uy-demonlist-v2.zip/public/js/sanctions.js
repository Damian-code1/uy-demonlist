// =============================================
// SANCTIONS.JS — Panel de Sanciones (rojo)
// =============================================

let sanctionsUsers = [];
let sanctionsLog    = [];

function canManageSanctions() {
  return window.currentUser && typeof isAdminRole === 'function' && isAdminRole(window.currentUser.role);
}

function openSanctionsPanel() {
  if (!canManageSanctions()) {
    showToast('No tenés permiso para acceder a este panel', 'error');
    return;
  }
  document.getElementById('sanctionsPanel')?.classList.add('open');
  document.getElementById('sanctionsOverlay')?.classList.add('open');
  document.body.style.overflow = 'hidden';
  window._scrollbarSetVisible?.(false);
  loadSanctionsUsers();
}

function closeSanctionsPanel() {
  document.getElementById('sanctionsPanel')?.classList.remove('open');
  document.getElementById('sanctionsOverlay')?.classList.remove('open');
  document.body.style.overflow = '';
  window._scrollbarSetVisible?.(true);
}

async function sanctionsFetch(path, opts = {}) {
  const discordId = localStorage.getItem('uy_discord_id');
  const res = await fetch(`${API_BASE}/admin/sanctions${path}`, {
    headers: { 'Content-Type': 'application/json', 'x-discord-id': discordId || '' },
    ...opts
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `HTTP ${res.status}`);
  }
  return res.json();
}

async function loadSanctionsUsers() {
  const container = document.getElementById('sanctions-users-table');
  if (!container) return;
  container.innerHTML = `<div class="loader-wrap"><i class="fas fa-spinner fa-spin"></i><span>Cargando usuarios…</span></div>`;

  try {
    const data = await sanctionsFetch('');
    sanctionsUsers = data.users || [];
    sanctionsLog   = data.log   || [];
    renderSanctionsUsers('');
  } catch (e) {
    container.innerHTML = `<div class="admin-notice error"><i class="fas fa-exclamation-circle"></i> ${esc(e.message)}</div>`;
  }
}

function fmtRemaining(expiresAt) {
  const diff = new Date(expiresAt).getTime() - Date.now();
  if (diff <= 0) return 'Expirado';
  const h = Math.floor(diff / 3600000);
  const m = Math.floor((diff % 3600000) / 60000);
  if (h > 0) return `${h}h ${m}m restantes`;
  return `${m}m restantes`;
}

function renderSanctionsUsers(filterQ) {
  const container = document.getElementById('sanctions-users-table');
  if (!container) return;

  const q = (filterQ || '').trim().toLowerCase();
  const filtered = q
    ? sanctionsUsers.filter(u =>
        (u.display_label || '').toLowerCase().includes(q) ||
        (u.discord_username || '').toLowerCase().includes(q) ||
        (u.gd_username || '').toLowerCase().includes(q))
    : sanctionsUsers;

  if (!filtered.length) {
    container.innerHTML = `<div class="admin-empty"><i class="fas fa-shield-alt"></i><span>Sin usuarios encontrados</span></div>`;
    return;
  }

  container.innerHTML = `
    <div class="sa-hint">
      <i class="fas fa-info-circle"></i>
      <span>Los usuarios sancionados no pueden enviar submissions hasta que finalice el tiempo de penalización.</span>
    </div>
    <div class="sa-list">
      ${filtered.map(u => {
        const avatar = u.avatar_url
          ? `<img src="${esc(u.avatar_url)}" alt="" class="sa-avatar">`
          : `<div class="sa-avatar sa-avatar-ph">${(u.display_label || '?')[0].toUpperCase()}</div>`;
        const isOwner = u.role === 'owner';

        return `
        <div class="sa-card${u.is_banned ? ' sa-card-banned' : ''}" data-discord-id="${esc(u.discord_id)}">
          <div class="sa-card-header">
            <div class="sa-avatar-wrap">
              ${avatar}
              ${u.is_banned ? `<span class="sa-ban-dot" title="Sancionado"></span>` : ''}
            </div>
            <div class="sa-user-info">
              <div class="sa-display-name">${esc(u.display_label)}</div>
              <div class="sa-discord-handle">@${esc(u.discord_username)}</div>
            </div>
            ${u.is_banned
              ? `<div class="sa-status-badge sa-status-banned">
                   <i class="fas fa-ban"></i>
                   <span>${fmtRemaining(u.banned_until)}</span>
                 </div>`
              : `<div class="sa-status-badge sa-status-ok">
                   <i class="fas fa-check-circle"></i>
                   <span>Sin sanciones</span>
                 </div>`
            }
          </div>

          ${u.is_banned && u.ban_reason ? `
          <div class="sa-ban-reason">
            <i class="fas fa-comment-dots"></i> ${esc(u.ban_reason)}
            ${u.banned_by ? ` <span class="sa-ban-by">— ${esc(u.banned_by)}</span>` : ''}
          </div>` : ''}

          <div class="sa-card-actions">
            ${isOwner
              ? `<div class="sa-owner-protected"><i class="fas fa-crown"></i> Owner protegido</div>`
              : u.is_banned
                ? `<button class="sa-btn sa-btn-lift" onclick="liftSanction('${esc(u.discord_id)}')">
                     <i class="fas fa-unlock"></i><span>Levantar sanción</span>
                   </button>`
                : `<button class="sa-btn sa-btn-ban" onclick="openBanModal('${esc(u.discord_id)}','${esc(u.display_label)}')">
                     <i class="fas fa-gavel"></i><span>Sancionar</span>
                   </button>`
            }
          </div>
        </div>`;
      }).join('')}
    </div>`;
}

function filterSanctionsUsers(q) {
  renderSanctionsUsers(q);
  const clearBtn = document.getElementById('sanctionsUserClear');
  if (clearBtn) clearBtn.style.display = q ? '' : 'none';
}

// ─── Modal de sanción ───
let banTargetId = null;

function openBanModal(discordId, label) {
  banTargetId = discordId;
  document.getElementById('banModalTarget').textContent = label;
  document.getElementById('banModalReason').value = '';
  document.getElementById('banModalDuration').value = '60';
  document.getElementById('banModal')?.classList.add('open');
}

function closeBanModal() {
  document.getElementById('banModal')?.classList.remove('open');
  banTargetId = null;
}

async function confirmBanUser() {
  if (!banTargetId) return;
  const duration = parseInt(document.getElementById('banModalDuration').value) || 0;
  const reason   = document.getElementById('banModalReason').value.trim();

  if (duration <= 0) { showToast('Duración inválida', 'error'); return; }

  try {
    await sanctionsFetch('', {
      method: 'POST',
      body: JSON.stringify({ discordId: banTargetId, durationMinutes: duration, reason })
    });
    showToast('Usuario sancionado ✓', 'success');
    closeBanModal();
    loadSanctionsUsers();
  } catch (e) {
    showToast('Error: ' + e.message, 'error');
  }
}

async function liftSanction(discordId) {
  try {
    await sanctionsFetch(`?discordId=${encodeURIComponent(discordId)}`, { method: 'DELETE' });
    showToast('Sanción levantada ✓', 'success');
    loadSanctionsUsers();
    // Si el usuario sancionado es el actual, refrescar su sesión
    if (window.currentUser?.discordId === discordId && typeof checkSession === 'function') {
      window.currentUser = await checkSession();
      renderUserWidget(window.currentUser);
      hideBanCountdown();
    }
  } catch (e) {
    showToast('Error: ' + e.message, 'error');
  }
}

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('sanctionsClose')?.addEventListener('click', closeSanctionsPanel);
  document.getElementById('sanctionsOverlay')?.addEventListener('click', closeSanctionsPanel);
  document.getElementById('navSanctionsBtn')?.addEventListener('click', openSanctionsPanel);

  document.getElementById('sanctionsUserClear')?.addEventListener('click', () => {
    const input = document.getElementById('sanctionsUserSearch');
    if (input) { input.value = ''; input.focus(); }
    document.getElementById('sanctionsUserClear').style.display = 'none';
    filterSanctionsUsers('');
  });

  document.getElementById('banModalCancel')?.addEventListener('click', closeBanModal);
  document.getElementById('banModalConfirm')?.addEventListener('click', confirmBanUser);
  document.querySelector('#banModal .modal-backdrop')?.addEventListener('click', closeBanModal);
});

window.openSanctionsPanel   = openSanctionsPanel;
window.closeSanctionsPanel  = closeSanctionsPanel;
window.filterSanctionsUsers = filterSanctionsUsers;
window.openBanModal         = openBanModal;
window.closeBanModal        = closeBanModal;
window.confirmBanUser       = confirmBanUser;
window.liftSanction         = liftSanction;
window.canManageSanctions   = canManageSanctions;

// =============================================
// COUNTDOWN FLOTANTE — visible para el usuario baneado
// =============================================
let _banCountdownInterval = null;

function showBanCountdown(bannedUntil, reason) {
  let el = document.getElementById('banCountdownFloat');
  if (!el) {
    el = document.createElement('div');
    el.id = 'banCountdownFloat';
    el.className = 'ban-countdown-float';
    document.body.appendChild(el);
  }

  el.innerHTML = `
    <div class="ban-countdown-glow"></div>
    <div class="ban-countdown-inner">
      <div class="ban-countdown-icon"><i class="fas fa-gavel"></i></div>
      <div class="ban-countdown-text">
        <span class="ban-countdown-label">SANCIONADO</span>
        <span class="ban-countdown-timer" id="banCountdownTimer">--:--:--</span>
      </div>
    </div>
    ${reason ? `<div class="ban-countdown-reason"><i class="fas fa-comment-dots"></i> ${esc(reason)}</div>` : ''}
  `;
  el.classList.add('visible');

  clearInterval(_banCountdownInterval);
  _banCountdownInterval = setInterval(() => {
    const diff = new Date(bannedUntil).getTime() - Date.now();
    if (diff <= 0) {
      clearInterval(_banCountdownInterval);
      hideBanCountdown();
      showToast('Tu sanción ha finalizado, ya podés enviar submissions', 'success');
      if (typeof checkSession === 'function') {
        checkSession().then(u => { window.currentUser = u; renderUserWidget(u); });
      }
      return;
    }
    const h = Math.floor(diff / 3600000);
    const m = Math.floor((diff % 3600000) / 60000);
    const s = Math.floor((diff % 60000) / 1000);
    const timerEl = document.getElementById('banCountdownTimer');
    if (timerEl) timerEl.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
  }, 1000);
}

function hideBanCountdown() {
  document.getElementById('banCountdownFloat')?.classList.remove('visible');
  clearInterval(_banCountdownInterval);
}

window.showBanCountdown = showBanCountdown;
window.hideBanCountdown = hideBanCountdown;