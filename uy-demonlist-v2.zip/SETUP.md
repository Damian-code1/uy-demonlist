# UY Demonlist v2 — Guía de Setup

## ⚡ Inicio Rápido (Modo Estático — Sin API)

Si solo querés ver la lista funcionando **sin instalar nada**:

1. Abrí `index.html` directamente en el navegador
2. Los datos se cargan desde `data/levels.json` automáticamente
3. El login de Discord y el panel admin requieren la API (Next.js)

---

## 🚀 Setup Completo (Con API + Admin)

### 1. Requisitos

- Node.js 18+
- WAMP / XAMPP corriendo (MySQL)
- Cuenta en [Discord Developer Portal](https://discord.com/developers/applications)

---

### 2. Base de Datos

Abrí tu cliente MySQL (phpMyAdmin o línea de comando):

```sql
CREATE DATABASE IF NOT EXISTS uy_demonlist CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
```

Luego importá el esquema:

```bash
mysql -u root -p uy_demonlist < database/schema.sql
```

---

### 3. Variables de Entorno

Copiá `.env.example` a `.env.local` y completá:

```bash
cp .env.example .env.local
```

Editá `.env.local`:

```env
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=           # tu contraseña de MySQL (vacío si no tiene)
DB_NAME=uy_demonlist

DISCORD_CLIENT_ID=     # de Discord Developer Portal
DISCORD_CLIENT_SECRET= # de Discord Developer Portal

NEXTAUTH_URL=http://localhost:3001
```

---

### 4. Discord OAuth Setup

1. Ir a [Discord Developer Portal](https://discord.com/developers/applications)
2. Crear nueva aplicación → OAuth2 → Redirects
3. Agregar redirect: `http://localhost:3001/api/auth/callback/discord`
4. Copiar **Client ID** y **Client Secret** a `.env.local`

---

### 5. Instalar y Correr

```bash
npm install
npm run migrate    # importa levels.json a MySQL
npm run dev        # API en http://localhost:3001
```

---

### 6. Configurar Owner/Admin

Después de hacer login con Discord, obtenés tu Discord ID.
Actualizá la base de datos:

```sql
UPDATE users SET role = 'owner' WHERE discord_id = 'TU_DISCORD_ID';
```

También podés descomentar y editar la línea al final de `database/schema.sql`.

---

## 📁 Estructura de Archivos

```
├── index.html              # Frontend principal
├── css/
│   ├── main.css            # Estilos principales (v2)
│   ├── animations.css      # Animaciones
│   └── responsive.css      # Mobile/tablet
├── js/
│   ├── data.js             # Carga de datos + API helpers
│   ├── main.js             # Navbar + partículas
│   ├── demonlist.js        # Lista de niveles + leaderboard
│   ├── submissions.js      # Formulario de submissions
│   ├── auth.js             # Widget de usuario flotante + Discord OAuth
│   └── admin.js            # Panel de administración
├── data/
│   └── levels.json         # Datos locales (backup / modo estático)
├── app/api/                # Next.js API Routes
│   ├── levels/             # GET /api/levels
│   ├── players/            # GET /api/players
│   ├── submissions/        # GET+POST /api/submissions
│   ├── auth/               # session, logout, callback
│   └── admin/              # CRUD protegido (requiere rol admin)
├── lib/
│   ├── db.js               # Pool de MySQL
│   └── auth.js             # Middleware de autenticación
├── database/
│   └── schema.sql          # Esquema MySQL
└── scripts/
    └── migrate.js          # Importa levels.json → MySQL
```

---

## 🎮 Panel de Admin

Accesible para roles: `owner`, `admin`, `list_mod`

- **Niveles**: Agregar, editar, eliminar niveles de la lista
- **Victors**: CRUD de victors por nivel (con link de video)
- **Jugadores**: Editar puntos, completions, nivel más difícil
- **Submissions**: Aprobar / rechazar / eliminar submissions

---

## ❓ Problemas Comunes

**Los datos no cargan (sin API)**
→ Asegurate de servir `index.html` desde un servidor local (no `file://`)
→ Usá: `python3 -m http.server 8080` o Live Server de VSCode

**Error de CORS**
→ Verificá que el Next.js corre en puerto 3001
→ El `next.config.js` ya tiene los headers CORS configurados

**Login de Discord no funciona**
→ Verificá el redirect URI en Discord Developer Portal
→ Debe ser exactamente: `http://localhost:3001/api/auth/callback/discord`

**"No autorizado" en admin**
→ Verificá que tu usuario tiene `role = 'owner'` o `'admin'` en la tabla `users`
