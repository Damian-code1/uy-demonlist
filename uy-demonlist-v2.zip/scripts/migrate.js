/**
 * migrate.js — Importa data/levels.json a MySQL
 * Uso: node scripts/migrate.js
 */

import { readFileSync } from 'fs';
import { createPool } from 'mysql2/promise';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import dotenv from 'dotenv';

dotenv.config({ path: '.env.local' });

const __dirname = dirname(fileURLToPath(import.meta.url));

const pool = createPool({
  host:     process.env.DB_HOST     || 'localhost',
  user:     process.env.DB_USER     || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME     || 'uy_demonlist',
  multipleStatements: true
});

async function migrate() {
  console.log('📦 Iniciando migración...');

  const jsonPath = join(__dirname, '..', 'data', 'levels.json');
  const raw      = JSON.parse(readFileSync(jsonPath, 'utf8'));
  const levels   = raw.levels  || [];
  const players  = raw.players || [];

  const conn = await pool.getConnection();

  try {
    await conn.beginTransaction();

    // Clear existing data (order matters due to FKs)
    await conn.query('SET FOREIGN_KEY_CHECKS = 0');
    await conn.query('TRUNCATE TABLE victors');
    await conn.query('TRUNCATE TABLE levels');
    await conn.query('TRUNCATE TABLE players');
    await conn.query('SET FOREIGN_KEY_CHECKS = 1');
    console.log('  🗑  Tablas vaciadas');

    // Insert levels
    for (const level of levels) {
      const [res] = await conn.query(
        `INSERT INTO levels (name, position, placement, youtube_url) VALUES (?, ?, ?, ?)`,
        [
          level.name,
          level.position,
          level.placement || null,
          level.youtubeUrl || null
        ]
      );

      // Insert victors for this level
      const victors = level.victors || [];
      for (const v of victors) {
        await conn.query(
          `INSERT INTO victors (level_id, player_name, video_url) VALUES (?, ?, ?)`,
          [res.insertId, v.name, v.videoUrl || null]
        );
      }
    }
    console.log(`  ✅ ${levels.length} niveles insertados`);

    // Insert players
    for (const p of players) {
      await conn.query(
        `INSERT INTO players (name, points, completions, hardest_level)
         VALUES (?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE points = VALUES(points), completions = VALUES(completions)`,
        [p.name, p.points || 0, p.completions || p.extremeCount || 0, p.hardest || null]
      );
    }
    console.log(`  ✅ ${players.length} jugadores insertados`);

    await conn.commit();
    console.log('\n🎉 Migración completada exitosamente!');
  } catch (err) {
    await conn.rollback();
    console.error('❌ Error en migración:', err);
    process.exit(1);
  } finally {
    conn.release();
    await pool.end();
  }
}

migrate();
