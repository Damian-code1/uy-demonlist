import { query } from '../../../../lib/db.js';
import { requireSanctionsAdmin } from '../../../../lib/auth.js';
import { ensureSchema } from '../../../../lib/schema.js';

export async function GET(request) {
  const admin = await requireSanctionsAdmin(request);
  if (!admin) return Response.json({ error: 'No autorizado' }, { status: 401 });

  try {
    await ensureSchema();

    const [users] = await query(`
      SELECT id, discord_id, discord_username, discord_display_name, discord_avatar,
             gd_username, linked_player_name, role, banned_until, ban_reason, banned_by
      FROM users
      ORDER BY (banned_until IS NOT NULL AND banned_until > NOW()) DESC, updated_at DESC
    `);

    const enriched = users.map(u => ({
      ...u,
      avatar_url: u.discord_avatar
        ? `https://cdn.discordapp.com/avatars/${u.discord_id}/${u.discord_avatar}.png`
        : null,
      display_label: u.discord_display_name || u.discord_username,
      is_banned: !!(u.banned_until && new Date(u.banned_until) > new Date()),
    }));

    const [log] = await query(`
      SELECT * FROM sanctions_log ORDER BY created_at DESC LIMIT 50
    `);

    return Response.json({ users: enriched, log });
  } catch (error) {
    console.error('[/api/admin/sanctions] GET Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function POST(request) {
  const admin = await requireSanctionsAdmin(request);
  if (!admin) return Response.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { discordId, durationMinutes, reason } = await request.json();
    if (!discordId)        return Response.json({ error: 'discordId requerido' }, { status: 400 });
    if (!durationMinutes || durationMinutes <= 0)
      return Response.json({ error: 'Duración inválida' }, { status: 400 });

    const [targetRows] = await query(
      'SELECT id, discord_username, discord_display_name, role FROM users WHERE discord_id = ? LIMIT 1',
      [discordId]
    );
    if (!targetRows.length) return Response.json({ error: 'Usuario no encontrado' }, { status: 404 });
    const target = targetRows[0];

    if (target.role === 'owner') {
      return Response.json({ error: 'No se puede sancionar al owner' }, { status: 403 });
    }

    const expiresAt = new Date(Date.now() + durationMinutes * 60 * 1000);

    await query(
      'UPDATE users SET banned_until = ?, ban_reason = ?, banned_by = ? WHERE discord_id = ?',
      [expiresAt, reason?.trim() || null, admin.discord_username, discordId]
    );

    await query(
      `INSERT INTO sanctions_log
       (discord_id, display_label, reason, duration_minutes, banned_by, banned_by_label, expires_at)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        discordId,
        target.discord_display_name || target.discord_username,
        reason?.trim() || null,
        durationMinutes,
        admin.id,
        admin.discord_username,
        expiresAt,
      ]
    );

    return Response.json({ success: true, expiresAt });
  } catch (error) {
    console.error('[/api/admin/sanctions] POST Error:', error);
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function DELETE(request) {
  const admin = await requireSanctionsAdmin(request);
  if (!admin) return Response.json({ error: 'No autorizado' }, { status: 401 });

  try {
    const { searchParams } = new URL(request.url);
    const discordId = searchParams.get('discordId');
    if (!discordId) return Response.json({ error: 'discordId requerido' }, { status: 400 });

    await query(
      'UPDATE users SET banned_until = NULL, ban_reason = NULL, banned_by = NULL WHERE discord_id = ?',
      [discordId]
    );
    await query(
      'UPDATE sanctions_log SET lifted_early = 1 WHERE discord_id = ? AND expires_at > NOW()',
      [discordId]
    );

    return Response.json({ success: true });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}

export async function OPTIONS() {
  return new Response(null, {
    status: 204,
    headers: {
      'Access-Control-Allow-Origin':  '*',
      'Access-Control-Allow-Methods': 'GET,POST,DELETE,OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type,x-discord-id',
    },
  });
}